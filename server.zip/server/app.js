import express from 'express';
import connectDB from './src/config/db.js';
import cors from 'cors';
import cookieParser from 'cookie-parser';

// Routes
import authRoute from './src/routes/UserRoutes.js';
import tourRoute from './src/routes/TourRoutes.js';
import PackageRoute from './src/routes/PackageRoutes.js';
import HotelRoute from './src/routes/HotelRoutes.js';

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(
  cors({
    origin: true,
    credentials: true,
  })
);

app.use(express.json());
app.use(cookieParser());

// API Endpoints
app.use('/api/auth', authRoute);
app.use('/api/tours', tourRoute);
app.use('/api/packages', PackageRoute);
app.use('/api/hotels', HotelRoute);

// Start server
const startServer = async () => {
  try {
    await connectDB();

    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();